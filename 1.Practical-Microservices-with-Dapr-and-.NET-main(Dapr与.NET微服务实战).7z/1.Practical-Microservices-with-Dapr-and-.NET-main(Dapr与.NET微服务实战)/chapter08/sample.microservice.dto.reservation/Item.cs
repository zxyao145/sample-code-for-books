﻿using System;

namespace sample.microservice.dto.reservation
{

    public class Item
        {
            public string SKU {get; set;}
            public int BalanceQuantity { get; set; }
        }
}
