az aks start --name daprk8saksdb --resource-group daprk8srgdb
az aks stop --name daprk8saksdb --resource-group daprk8srgdb